$(function(){

    // 네비
    var $open= $('.btn-menu');
    var $close= $('.btn-close');
    var $menu= $('.nav');

    $open.on('click',function(){
        $menu.fadeIn();
    });
    $close.on('click',function(){
        $menu.fadeOut();
    });
    
    // 전시공간 바로가기
    var $quickLink= $('.quick-link');
    var $qlist= $('.q-list');
    $quickLink.on('click',function(){
        if($(this).hasClass('on')){
            $(this).removeClass('on');
            $qlist.slideUp(0);
        }else{
            $(this).addClass('on');
            $qlist.slideDown(0);
        }
    });

    // header
    if($('.header.white').length > 0) {
        $(window).on('scroll', function(){
            if (window.innerWidth > 1024) {
                var yOffset = window.pageYOffset;
                if(yOffset >= 100){
                    $('.header.white').addClass('static');
                }else{
                    $('.header.white').removeClass('static');
                }
            }
        });
    }

    $(window).on('load', function(){
        $('body').addClass('on');
    });
})

